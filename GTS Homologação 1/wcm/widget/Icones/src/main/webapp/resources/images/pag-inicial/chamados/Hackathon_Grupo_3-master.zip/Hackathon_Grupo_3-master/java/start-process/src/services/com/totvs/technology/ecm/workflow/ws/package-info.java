@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.workflow.ecm.technology.totvs.com/")
package services.com.totvs.technology.ecm.workflow.ws;
