function afterProcessCreate(processId){
	hAPI.setCardValue("processid", processId);
}