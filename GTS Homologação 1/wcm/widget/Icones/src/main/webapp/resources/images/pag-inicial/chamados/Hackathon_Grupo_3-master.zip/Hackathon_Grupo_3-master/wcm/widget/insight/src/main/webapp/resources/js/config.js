AWS.config.region = 'us-east-1';
AWS.config.update({
    "accessKeyId": "XXX",
    "secretAccessKey": "YYY",
});