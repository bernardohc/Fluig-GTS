@javax.xml.bind.annotation.XmlSchema(namespace = "http://jaxb.dev.java.net/array")
package services.net.java.dev.jaxb.array;
